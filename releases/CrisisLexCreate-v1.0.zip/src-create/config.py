# replace with the label of class for which you are interested in building the lexicon;
# this should be the same as the label in your input files
positive_class_label = "on-topic"

# replace the label for the examples that do not belong to the topic of interest
# this should be the same as the label in your input files
negative_class_label ="off-topic"

# lexicon size
lexicon_size = 400