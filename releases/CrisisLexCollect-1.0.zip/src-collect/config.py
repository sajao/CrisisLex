#Sets Twitter API access

#Please give the keys as 'strings' 
CONSUMER_KEY = '' # API key
CONSUMER_SECRET = '' # API secret
ACCESS_KEY = '' # Access token
ACCESS_SECRET= '' # Access token secret
